# MistriAdda Plugin

A Flutter plugin for listing and searching mistri services like Electricians, Plumbers, Painters, etc.

## Usage

```dart
import 'package:mistri_adda_plugin/mistri_adda_plugin.dart';

void main() {
  runApp(MaterialApp(
    home: SearchScreen(),
  ));
}
```
