import 'package:flutter/material.dart';
import 'mistri_list_screen.dart';

class SearchScreen extends StatelessWidget {
  final cities = ['Jaipur', 'Delhi', 'Mumbai'];
  final mistriTypes = ['Electrician', 'Plumber', 'Mechanic', 'Painter'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepOrange,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('MistriAdda', style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  TextField(
                    decoration: InputDecoration(
                      hintText: 'Search city',
                      fillColor: Colors.white,
                      filled: true,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    items: mistriTypes.map((String type) => DropdownMenuItem<String>(
                      value: type,
                      child: Text(type),
                    )).toList(),
                    onChanged: (value) {},
                    decoration: InputDecoration(
                      hintText: 'Select mistri type',
                      fillColor: Colors.white,
                      filled: true,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MistriListScreen())),
                    child: Text('Search'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.yellow, foregroundColor: Colors.black),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
