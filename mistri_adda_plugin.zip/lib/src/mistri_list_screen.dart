import 'package:flutter/material.dart';

class MistriListScreen extends StatelessWidget {
  final List<Map<String, String>> mistris = [
    {'name': 'Rajesh Kumar', 'type': 'Painter'},
    {'name': 'Sunita Verma', 'type': 'Painter'},
    {'name': 'Anil Sharma', 'type': 'Painter'},
    {'name': 'Anxi Sharma', 'type': 'Painter'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MistriAdda')),
      body: ListView.builder(
        itemCount: mistris.length,
        itemBuilder: (context, index) {
          final mistri = mistris[index];
          return ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text(mistri['name']!),
            subtitle: Text(mistri['type']!),
          );
        },
      ),
    );
  }
}
